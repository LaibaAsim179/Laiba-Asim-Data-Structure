#include<iostream>
using namespace std;
struct Node 
{
    int data;
    Node* link;
};
struct Queue
{
    Node* front;
    Node* rear;
    Queue() 
	{
        front=rear=NULL;
    }
};
void enQueue(Queue* q, int value) 
{
    Node* temp=new Node();
    temp->data=value;
    temp->link=NULL;

    if (q->front == NULL) 
	{
        q->front = temp;
    } 
	else
	{
        q->rear->link = temp;
    }
    q->rear = temp;
    q->rear->link = q->front;
}

int deQueue(Queue* q) 
{
    if (q->front == NULL) 
	{
        cout<<"queue is empty!"<<endl;
        return -1;
    }
    int value;
    if (q->front == q->rear) 
	{
        value = q->front->data;
        delete q->front;
        q->front = q->rear=NULL;
    } 
	else 
	{
        Node* temp = q->front;
        value = temp->data;
        q->front = q->front->link;
        q->rear->link = q->front;
        delete temp;
    }
    return value;
}
void displayQueue(Queue* q) 
{
    if (q->front ==NULL) 
	{
        cout<<"queue is empty!"<<endl;
        return;
    }
    Node* temp = q->front;
    cout<<"elements in Circular Queue are:"<<endl;

    do 
	{
        cout << temp->data << " ";
        temp = temp->link;
    } while (temp != q->front);

    cout << endl;
}

int main() 
{
    Queue q;
    enQueue(&q, 20);
    enQueue(&q, 30);
    enQueue(&q, 45);
    displayQueue(&q);
    cout << "deleted value = " << deQueue(&q) << endl;
    cout << "deleted value = " << deQueue(&q) << endl;
    displayQueue(&q);
    enQueue(&q, 15);
    enQueue(&q, 35);
    displayQueue(&q);
    return 0;
}

