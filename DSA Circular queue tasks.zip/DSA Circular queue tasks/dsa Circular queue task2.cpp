#include<iostream>
using namespace std;
class CircularQueue 
{
private:
    int size;
    int front, rear;
    int* queue;
public:
    CircularQueue(int s) 
	{
        size = s;
        front = rear = -1;
        queue = new int[size];
    }
    ~CircularQueue() 
	{
        delete[] queue;
    }
    void enQueue(int data)
	{
        if ((front == 0 && rear == size - 1) ||(rear == (front - 1 + size) % size)) 
		{
            cout <<"queue is Full!"<<endl;
            return;
        }
        else if (front == -1) 
		{
            front = rear = 0;
            queue[rear] = data;
        }
        else if (rear == size - 1 && front != 0) 
		{
            rear = 0;
            queue[rear]=data;
        }
        else 
		{
            rear++;
            queue[rear]=data;
        }
    }
    int deQueue() 
	{
        if (front == -1) 
		{
            cout<<"queue is empty!"<<endl;
            return -1;
        }

        int temp = queue[front];
        if (front == rear) 
		{
            front = rear = -1;
        }
        else if (front == size - 1) 
		{
            front = 0;
        }
        else 
		{
            front++;
        }
        return temp;
    }
    void displayQueue() 
	{
        if (front == -1) 
		{
            cout<<"queue is empty!"<<endl;
            return;
        }

        cout<<"elements in the circular queue are:"<<endl;
        if (rear >= front) 
		{
            for (int i=front; i<=rear;i++) 
			{
                cout<<queue[i] << " ";
            }
        }
        else 
		{
            for (int i=front; i<size;i++) 
			{
                cout<<queue[i]<<" ";
            }
            for (int i = 0; i <= rear; i++) 
			{
                cout<<queue[i]<< " ";
            }
        }
        cout << endl;
    }
};
int main() 
{
    CircularQueue q(20);

    q.enQueue(10);
    q.enQueue(55);
    q.enQueue(23);
    q.enQueue(-8);
    q.displayQueue();
    int x = q.deQueue();
    if (x != -1)
    cout<<"deleted value:"<<x<<endl;

    x = q.deQueue();
    if (x != -1)
    cout<<"deleted value:"<<x<<endl;

    q.displayQueue();
    q.enQueue(23);
    q.enQueue(35);
    q.enQueue(9);
    q.displayQueue();

    q.enQueue(12);
    return 0;
}



