#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node*prev;
    Node*next;
};
Node*head=NULL;
void createList(int n) 
{
    Node*temp,*newNode;
    int data;
    if(n <= 0) 
	{
        cout<<"List size must be greater than 0!"<<endl;
        return;
    }
    cout<<"Enter value for node 1: ";
    cin>>data;
    head=new Node{data, NULL, NULL};
    temp=head;
    for(int i = 2; i <= n; i++) 
	{
        cout<<"Enter value for node"<<i<< ": ";
        cin>>data;
        newNode=new Node{data, temp, NULL};
        temp->next=newNode;
        temp=newNode;
    }
}
void addAtBeginning(int value) 
{
    Node* newNode=new Node{value, NULL, head};
    if(head!=NULL)
        head->prev=newNode;
    head=newNode;
}
void addAfter45(int value) 
{
    Node* temp = head;
    while(temp != NULL && temp->data != 45) 
	{
        temp=temp->next;
    }
    if(temp==NULL) 
	{
        cout<<"Value 45 not found in the list!"<<endl;
        return;
    }

    Node*newNode=new Node{value, temp, temp->next};
    if(temp->next!=NULL)
        temp->next->prev=newNode;
    temp->next=newNode;
}
void deleteAtBeginning() 
{
    if(head==NULL) 
	{
        cout<<"List is empty:"<<endl;
        return;
    }
    Node*temp=head;
    head=head->next;
    if(head!=NULL)
        head->prev=NULL;
    delete temp;
}
void deleteAfter45() 
{
    Node* temp=head;
    while(temp != NULL && temp->data != 45) 
	{
        temp=temp->next;
    }
    if(temp == NULL||temp->next == NULL) 
	{
        cout<<"No node exists after 45:"<<endl;
        return;
    }
    Node* toDelete = temp->next;
    temp->next = toDelete->next;
    if(toDelete->next != NULL)
        toDelete->next->prev = temp;
    delete toDelete;
}
void display() 
{
    Node* temp = head;
    cout << "List: ";
    while(temp != NULL) 
	{
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
int main() 
{
    int n;
    cout << "Enter number of nodes to create: ";
    cin >> n;
    createList(n);
    display();
    cout <<"Adding 10 at beginning:" << endl;
    addAtBeginning(10);
    display();
    cout <<"Adding 35 after 45:"<<endl;
    addAfter45(35);
    display();
    cout<<"\nDeleting node at beginning:"<<endl;
    deleteAtBeginning();
    display();
    cout << "\nDeleting node after 45:"<<endl;
    deleteAfter45();
    display();
    return 0;
}

