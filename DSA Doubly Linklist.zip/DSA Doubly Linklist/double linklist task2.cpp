#include <iostream>
using namespace std;
struct Node 
{
    int data;   
    int day;    
    Node* prev;
    Node* next;
};
int main() 
{
    Node*head=NULL;
    Node*tail=NULL;
    int rainfall;
    cout<<"Enter rainfall (in mm) for 7 days:"<<endl;
    for (int i = 1; i <= 7; i++) 
	{ 
        do 
		{
            cout<<"Day:"<<i<<endl;
            cin>>rainfall;
            if(rainfall<0) 
			{
                cout<<"Invalid! Rainfall cannot negative!"<<endl;
            }
        } 
		while(rainfall<0);
        Node*newNode=new Node;
        newNode->data=rainfall;
        newNode->day=i;
        newNode->prev=tail;
        newNode->next=NULL;

        if (tail!=NULL) 
		{
            tail->next=newNode;
        } else 
		{
            head=newNode;
        }
        tail=newNode;
    }
    int total=0;
    Node*temp=head;
    while(temp!=NULL) 
	{
        total+=temp->data;
        temp=temp->next;
    }
    cout<<"Total Rainfall for the week:"<<total<<"mm"<<endl;
    cout<<"Average Rainfall for the week:"<<(total / 7.0)<<"mm"<<endl;

    Node*maxNode=head;
    temp=head;
    while(temp!=NULL) 
	{
        if (temp->data>maxNode->data) 
		{
            maxNode=temp;
        }
        temp=temp->next;
    }
    cout<<"Day"<<maxNode->day<<"had the highest rainfall:"<<maxNode->data<<"mm";
    Node*minNode=head;
    temp=head;
    while (temp!=NULL) 
	{
        if (temp->data < minNode->data) 
		{
            minNode=temp;
        }
        temp=temp->next;
    }
    cout<<"Day "<< minNode->day << " had the lowest rainfall: "<<minNode->data<<"mm"<<endl;
    temp = head;
    int count = 1;
    while (temp!=NULL && count < 6) 
	{
        temp = temp->next;
        count++;
    }
    if (temp!=NULL)
        cout<<"Rainfall of the day after 5th node (Day 6): "<<temp->data<<"mm"<<endl;
    else
        cout<<"There is no day after the 5th node:"<<endl;
    return 0;
}

