#include <iostream>
#include <string>
using namespace std;
struct Node 
{
    string name;
    int score;
    Node* prev;
    Node* next;
};
Node* head = NULL;   
void addPlayer(string name, int score) 
{
    Node* newNode = new Node{name, score, NULL, NULL};

    if (head == NULL) 
	{
        head = newNode;
        return;
    }
    Node* temp = head;
    Node* prevNode = NULL;
    while (temp != NULL && temp->score <= score) 
	{
        prevNode = temp;
        temp = temp->next;
    }

    if (prevNode == NULL) 
	{  
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    } else if (temp == NULL) 
	{ 
        prevNode->next = newNode;
        newNode->prev = prevNode;
    } else 
	{ 
        prevNode->next = newNode;
        newNode->prev = prevNode;
        newNode->next = temp;
        temp->prev = newNode;
    }
}

void deletePlayer(string name) 
{
    Node* temp = head;
    while (temp !=NULL && temp->name != name) 
	{
        temp = temp->next;
    }

    if (temp == NULL) 
	{
        cout << "Player not found!"<<endl;;
        return;
    }

    if (temp->prev !=NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next; 

    if (temp->next !=NULL)
        temp->next->prev = temp->prev;

    delete temp;
    cout << "Player deleted successfully:"<<endl;
}
void displayAll() 
{
    if (head ==NULL) 
	{
        cout << "No players in the list:"<<endl;
        return;
    }
    Node* temp = head;
    cout << "Players List (Ascending order by score):"<<endl;
    while (temp !=NULL) 
	{
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}
void displayLowest() 
{
    if (head == NULL) 
	{
        cout << "No players available."<<endl;
        return;
    }
    cout<<"Player with lowest score:"<< head->name << " - " << head->score << endl;
}
void displaySameScore(int score) 
{
    Node* temp = head;
    bool found = false;
    cout << "Players with score " << score <<endl;
    while (temp != NULL) 
	{
        if (temp->score == score) 
		{
            cout << temp->name << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No players found with this score:"<<endl;
}
void displayBackward(string name) {
    Node* temp = head;
    while (temp !=NULL  && temp->name != name) 
	{
        temp = temp->next;
    }
    if (temp == NULL) 
	{
        cout << "Player not found!"<<endl;
        return;
    }
    cout << "Players backward from " << name << endl;
    while (temp != NULL) 
	{
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->prev;
    }
}
int main() 
{
    int choice;
    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add new Player\n";
        cout << "2. Delete a Player\n";
        cout << "3. Display all Players\n";
        cout << "4. Display Player with Lowest Score\n";
        cout << "5. Display all Players with same Score\n";
        cout << "6. Display Backward from a Player\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        if (choice == 1) 
		{
            string name; int score;
            cout << "Enter Player Name: ";
            cin >> name;
            cout << "Enter Player Score: ";
            cin >> score;
            addPlayer(name, score);
        } 
        else if (choice == 2) 
		{
            string name;
            cout << "Enter Player Name to delete: ";
            cin >> name;
            deletePlayer(name);
        } 
        else if (choice == 3) 
		{
            displayAll();
        } 
        else if (choice == 4) 
		{
            displayLowest();
        } 
        else if (choice == 5) 
		{
            int score;
            cout << "Enter Score: ";
            cin >> score;
            displaySameScore(score);
        } 
        else if (choice == 6) 
		{
            string name;
            cout << "Enter Player Name: ";
            cin >> name;
            displayBackward(name);
        }
    } 
	while(choice != 7);
    return 0;
}

