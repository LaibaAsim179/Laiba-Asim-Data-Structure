#include <iostream>
using namespace std;
class Applicant 
{
public:
    int id;
    float height, weight, eyesight;
    string status;
    Applicant *next, *prev;
};
class Queue 
{
public:
    Applicant *front, *rear;
    Queue() { front = rear = NULL; }

    void insertApplicant(int id, float h, float w, float e, string st)
	{
        Applicant *temp = new Applicant;

        temp->id = id;
        temp->height = h;
        temp->weight = w;
        temp->eyesight = e;
        temp->status = st;
        temp->next = NULL;
        temp->prev = NULL;

        if (front == NULL) 
		{
            front = rear = temp;
        }
        else 
		{
            rear->next = temp;
            temp->prev = rear;
            rear = temp;
        }
        cout << "Applicant " << id << " joined the line." << endl;
    }

    void testDone() 
	{
        if (front == NULL) 
		{
            cout<<"No applicant in line!"<<endl;
            return;
        }

        cout << "Applicant " << front->id << " finished test and left!" << endl;
        if (front == rear) {
            front = rear = NULL;
        }
        else {
            front = front->next;
            front->prev = NULL;
        }
    }
    void removeSecond() {
        if (front == NULL || front->next == NULL) {
            cout << "No second applicant to remove." << endl;
            return;
        }

        Applicant *temp = front->next;
        cout << "Applicant " << temp->id << " had urgency and left." << endl;

        front->next = temp->next;
        if (temp->next != NULL)
            temp->next->prev = front;
        else
            rear = front;

        delete temp;
    }

    void display() {
        if (front == NULL) {
            cout << "No applicants in line." << endl;
            return;
        }

        Applicant *temp = front;
        cout << "\nCurrent Queue: ";
        while (temp != NULL) {
            cout << "[" << temp->id << "] ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() 
{
    Queue q;
    q.insertApplicant(1, 23.3 ,20, 1.4, "Pending");
    q.insertApplicant(2, 5.7, 22, 1.4, "Pending");
    q.insertApplicant(3, 5.8, 23, 1.2, "Pending");
    q.insertApplicant(4, 5.9, 12, 1.1, "Pending");
    q.insertApplicant(5, 6.1, 45, 1.6, "Pending");
    q.insertApplicant(6, 5.5, 58, 1.3, "Pending");
    q.insertApplicant(7, 5.4, 55, 1.9, "Pending");

    q.display();
    q.removeSecond();
    q.display();
    cout <<"Front Applicant Takes Test!"<<endl;
    q.testDone();
    q.display();
    return 0;
}

