#include <iostream>
#include <queue>
#include <stack>
using namespace std;
queue<int> road;   
stack<int> garage; 
void On_road(int id) 
{
    road.push(id);
    cout << "Truck " << id << " is on the road." << endl;
}

void Enter_garage() 
{
    if (road.empty()) 
	{
        cout << "No truck on road to enter garage." << endl;
        return;
    }
    int id = road.front();
    road.pop();
    garage.push(id);
    cout << "Truck " << id << " entered the garage." << endl;
}

void Exit_garage(int id) 
{
    if (garage.empty()) 
	{
        cout << "Garage is empty." << endl;
        return;
    }

    if (garage.top() == id) 
	{
        garage.pop();
        cout << "Truck " << id << " exited the garage." << endl;
    }
    else 
	{
        cout << "Truck is not near garage door." << endl;
    }
}
void Show_trucks(string where)
 {
    if (where == "road") 
	{
        cout<<"Road Trucks!";
        queue<int> temp = road;
        while (!temp.empty()) 
		{
            cout << temp.front() << " ";
            temp.pop();
        }
        cout << endl;
    }
    else if (where == "garage") 
	{
        cout << "Garage Trucks: ";
        stack<int> temp = garage;
        while (!temp.empty()) 
		{
            cout << temp.top() << " ";
            temp.pop();
        }
        cout << endl;
    }
}
int main() 
{
    On_road(80);
    On_road(40);
    On_road(60);
    Enter_garage();
    Enter_garage();
    Show_trucks("road");
    Show_trucks("garage");
    Exit_garage(40);
    Exit_garage(80);

    return 0;
}

