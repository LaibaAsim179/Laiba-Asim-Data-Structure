#include <iostream>
using namespace std;

// Node for stack
struct Node {
    int data;
    Node* next;
};

// Stack class
class Stack {
private:
    Node* top;  // Points to the top of stack

public:
    Stack() { 
	top = NULL; 
	} // Empty stack initially

    // Push element
    void push(int value) {
        Node* newNode = new Node();
        newNode->data = value;
        newNode->next = top;  // Point new node to current top
        top = newNode;        // New node becomes top
        cout << value << " pushed into stack.\n";
    }

    // Pop element
    void pop() {
        if (top == NULL) { // Stack empty
            cout << "Stack Underflow!\n";
            return;
        }
        cout << top->data << " popped from stack.\n";
        Node* temp = top;
        top = top->next;  // Move top down
        delete temp;      // Free memory
    }

    // Check if empty
    bool isEmpty() {
        return top == NULL;
    }

    // Display stack
    void display() {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Stack elements: ";
        Node* temp = top;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    // Destructor to free memory
    ~Stack() {
        while (!isEmpty())
            pop();
    }
};

// Main function
int main() {
    Stack s;

    s.push(5);
    s.push(10);
    s.push(15);
    s.display();  // 15 10 5

    s.pop();      // Remove top (15)
    s.display();  // 10 5

    return 0;
}
