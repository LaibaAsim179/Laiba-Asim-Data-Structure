#include <iostream>
using namespace std;

#define MAX 100  // Maximum size of stack

class Stack {
    int top;
    int a[MAX]; // Stack array

public:
    Stack() { top = -1; }  // Constructor

    // Push function 
    bool push(int x) {
        if (top >= MAX - 1) {
            cout << "Stack Overflow\n";
            return false;
        }
        a[++top] = x;
        cout << x << " pushed into stack\n";
        return true;
    }

    // Pop an element
    int pop() {
        if (top < 0) {
            cout << "Stack Underflow\n";
            return 0;
        }
        return a[top--];
    }

    // Return top element
    int peek() {
        if (top < 0) {
            cout << "Stack is Empty\n";
            return 0;
        }
        return a[top];
    }

    // Check if stack is empty
    bool isEmpty() {
        return (top < 0);
    }
};

// Main function
int main() {
    Stack s;

    s.push(10);
    s.push(20);
    s.push(30);

    cout << s.pop() << " popped from stack\n";
    cout << "Top element is: " << s.peek() << endl;

    cout << "Elements in stack: ";
    while (!s.isEmpty()) {
        cout << s.peek() << " ";
        s.pop();
    }

    return 0;
}

