#include <iostream>
#include <string>
#define MAX 10
using namespace std;
class Book {
public:
    string title;
    float price;
    int edition;
    int pages;

    Book() {}
    Book(string t, float p, int e, int pa) {
        title = t;
        price = p;
        edition = e;
        pages = p;
    }

    void display() const {
        cout << "Title: " << title
             << ", Price: " << price
             << ", Edition: " << edition
             << ", Pages: " << pages << endl;
    }
};

class Stack {
    int top;
    Book books[MAX]; 

public:
    Stack() { top = -1; }

    bool push(Book b);
    Book pop();
    Book peek();
    bool isEmpty();
    void displayAll();
};

bool Stack::push(Book b) {
    if (top >= MAX - 1) {
        cout << "Stack Overflow! Cannot add more books.\n";
        return false;
    }
    books[++top] = b;
    cout << "Book \"" << b.title << "\" pushed into stack.\n";
    return true;
}

Book Stack::pop() {
    if (top < 0) {
        cout << "Stack Underflow! No books to remove."<<endl;
        return Book();
    }
    cout << "Book \"" << books[top].title << "\" popped from stack."<<endl;
    return books[top--];
}
Book Stack::peek() {
    if (top < 0) {
        cout << "Stack is empty.\n";
        return Book();
    }
    return books[top];
}
bool Stack::isEmpty()
 {
    return (top < 0);
}

void Stack::displayAll() {
    if (isEmpty()) 
	{
        cout << "Stack is empty.\n";
        return;
    }

    cout << "Books currently in the stack:"<<endl;
    for (int i = top; i >= 0; i--) {
        cout << "[" << (i + 1) << "] ";
        books[i].display();
    }
}
int main() {
    Stack s;
    s.push(Book("C++", 950.21, 5, 120));
    s.push(Book("Data Structures", 780.20, 4, 803));
    s.push(Book("coal", 650.75, 2, 900));
    s.push(Book("Database Systems", 880.35, 6, 112));
    s.push(Book("Computer science", 720.12, 1, 725));

    cout << "Top book in the stack:"<<endl;
    s.peek().display();
    s.pop();
    s.pop();
    s.displayAll();
    return 0;
}

