#include <iostream>
using namespace std;
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;
public:
    Inventory() : serialNum(0), manufactYear(0), lotNum(0) {}
    Inventory(int s, int y, int l) : serialNum(s), manufactYear(y), lotNum(l) {}
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }
    void display()const 
	{
    cout <<"Serial Number:"<<serialNum<<endl;
    cout <<"Manufacture Year:"<<manufactYear<<endl;
    cout<<"Lot Number:"<<lotNum<<endl;
    }
};
struct Node {
    Inventory data;
    Node* next;
};
class Stack {
private:
    Node* top;
public:
    Stack() { top =NULL; }
    void push(const Inventory& inv) {
        Node* newNode = new Node;
        newNode->data = inv;
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory:"<<endl;
    }
    void pop() {
        if (isEmpty()) {
            cout << "Inventory is empty. Nothing to remove:"<<endl;
            return;
        }
        Node* temp = top;
        cout << "Removed part details:"<<endl;
        top->data.display();

        top = top->next;
        delete temp;
    }
    bool isEmpty() const {
        return (top ==NULL);
    }
    void displayAll() const {
        if (isEmpty()) {
            cout << "Inventory is empty:"<<endl;
            return;
        }

        cout << "Parts currently in inventory:"<<endl;
        Node* temp = top;
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
    }
    ~Stack() {
        while (!isEmpty()) {
            pop();
        }
    }
};
int main() {
    Stack inventoryStack;
    int choice;
    cout << " Inventory Management System"<<endl;
    do {
        cout << "\n1. Add part to inventory (Push)"
             << "\n2. Remove part from inventory (Pop)"
             << "\n3. Display all parts"
             << "\n4. Exit"
             << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory part(serial, year, lot);
            inventoryStack.push(part);
            break;
        }
        case 2:
            inventoryStack.pop();
            break;

        case 3:
            inventoryStack.displayAll();
            break;

        case 4:
            cout << "Final Inventory before exit:"<<endl;
            inventoryStack.displayAll();
            cout << "Exiting program:"<<endl;
            break;

        default:
            cout << "Invalid choice!Try again!"<<endl;
        }
    } while (choice != 4);
    return 0;
}

