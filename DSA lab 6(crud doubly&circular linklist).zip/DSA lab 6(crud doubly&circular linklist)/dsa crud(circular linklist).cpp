#include <iostream>
using namespace std;
struct Node 
{
    int data;
    Node* next;
};

Node* head = NULL;

void insertBeg(int x)
 {
    Node* n = new Node();
    n->data = x;
    if (head == NULL) 
	{
        head = n;
        n->next = head;
        return;
    }
    Node* t = head;
    while (t->next != head) t = t->next;
    n->next = head;
    t->next = n;
    head = n;
}

void insertEnd(int x) 
{
    Node* n = new Node();
    n->data = x;
    if (head == NULL) 
	{
        head = n;
        n->next = head;
        return;
    }
    Node* t = head;
    while (t->next != head) t = t->next;
    t->next = n;
    n->next = head;
}

void insertAfter(int key, int x) 
{
	
    if (head == NULL) return;
    Node* t = head;
    do {
        if (t->data == key) 
		{
            Node* n = new Node();
            n->data = x;
            n->next = t->next;
            t->next = n;
            return;
        }
        t = t->next;
    } while (t != head);
}

void deleteBeg() 
{
    if (head == NULL) return;
    Node* t = head;
    while (t->next != head) t = t->next;
    Node* d = head;
    head = head->next;
    t->next = head;
    delete d;
}

void deleteEnd() {
    if (head == NULL) return;
    Node *t = head, *p = NULL;
    while (t->next != head) {
        p = t;
        t = t->next;
    }
    if (p == NULL) head = NULL;
    else p->next = head;
    delete t;
}

void deleteValue(int key) 
{
    if (head == NULL) return;
    Node *t = head, *p = NULL;
    do {
        if (t->data == key) 
		{
            if (p == NULL) deleteBeg();
            else {
                p->next = t->next;
                delete t;
            }
            return;
        }
        p = t;
        t = t->next;
    } 
	while (t != head);
}

void search(int x) {
    if (head == NULL) 	{ cout << "Not Found\n"; return;}
    Node* t = head;
    do {
        if (t->data == x) { cout << "Found\n"; return; }
        t = t->next;
    } 
	while (t != head);
    cout << "Not Found"<<endl;
}

void update(int oldVal, int newVal) 
{
    if (head == NULL) return;
    Node* t = head;
    do 
	{
        if (t->data == oldVal) { t->data = newVal; return; }
        t = t->next;
    }
	 while (t != head);
}

void display() 
{
    if (head == NULL) { cout << endl; return; }
    Node* t = head;
    do 
	{
        cout << t->data << " ";
        t = t->next;
    }
	 while (t != head);
    cout << endl;
}

int main() 
{
    insertBeg(23);
    insertEnd(56);
    insertAfter(34, 20);
    display();
    deleteBeg();
    deleteEnd();
    deleteValue(23);
    insertEnd(40);
    update(87, 40);
    search(23);
    display();
    return 0;
}

