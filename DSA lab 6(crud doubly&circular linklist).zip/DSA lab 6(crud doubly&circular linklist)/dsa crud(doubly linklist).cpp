#include <iostream>
using namespace std;
struct Node 
{
    int data;
    Node *prev, *next;
};

Node* head = NULL;
void insertBeg(int x) 
{
    Node* n = new Node();
    n->data = x;
    n->prev = NULL;
    n->next = head;
    if (head != NULL) head->prev = n;
    head = n;
}

void insertEnd(int x) 
{
    Node* n = new Node();
    n->data = x;
    n->next = NULL;
    if (head == NULL) 
	{
        n->prev = NULL;
        head = n;
        return;
    }
    Node* t = head;
    while (t->next != NULL) t = t->next;
    t->next = n;
    n->prev = t;
}

void insertAfter(int key, int x) 
{
    Node* t = head;
    while (t != NULL && t->data != key) t = t->next;
    if (t == NULL) return;
    Node* n = new Node();
    n->data = x;
    n->next = t->next;
    n->prev = t;
    if (t->next != NULL) t->next->prev = n;
    t->next = n;
}

void deleteBeg() 
{
    if (head == NULL) return;
    Node* t = head;
    head = head->next;
    if (head != NULL) head->prev = NULL;
    delete t;
}

void deleteEnd()
 {
    if (head == NULL) return;
    Node* t = head;
    while (t->next != NULL) t = t->next;
    if (t->prev != NULL) t->prev->next = NULL;
    else head = NULL;
    delete t;
}

void deleteValue(int key) 
{
    Node* t = head;
    while (t != NULL && t->data != key) t = t->next;
    if (t == NULL) return;
    if (t->prev != NULL) t->prev->next = t->next;
    else head = t->next;
    if (t->next != NULL) t->next->prev = t->prev;
    delete t;
}

void search(int x) {
    Node* t = head;
    while (t != NULL) {
        if (t->data == x) { cout << "Found\n"; return; }
        t = t->next;
    }
    cout << "Not Found\n";
}

void update(int oldVal, int newVal) 
{
    Node* t = head;
    while (t != NULL) 
	{
        if (t->data == oldVal) { t->data = newVal; return; }
        t = t->next;
    }
}

void display()
 {
    Node* t = head;
    while (t != NULL) { cout << t->data << " "; t = t->next; }
    cout << endl;
}

int main() 
{
    insertBeg(23);
    insertEnd(64);
    insertAfter(11, 30);
    display();
    deleteBeg();
    deleteEnd();
    deleteValue(11);
    insertEnd(39);
    update(30, 50);
    search(23);
    display();
    return 0;
}

